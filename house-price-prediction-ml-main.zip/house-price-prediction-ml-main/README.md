# House Price Prediction Model

This model uses following 5 types of Linear Regression Algorithms

1. Ordinary Least Squares
2. Ridge Regression
3. Lasso 
4. Bayesian Regression
5. Elastic Net

- You can find more about them on [Scikit-Learn Documentation](https://scikit-learn.org/stable/modules/linear_model.html#ordinary-least-squares)

